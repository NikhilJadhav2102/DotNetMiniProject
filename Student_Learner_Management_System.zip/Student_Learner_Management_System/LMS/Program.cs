﻿using System;

namespace LMS
{

    class Program
    {

        static void Main(string[] args)
        {
            try
            {
              //  Menu.MenuList();
            }

            catch (Exception e)
            {
                Console.WriteLine("Exception occurred " + e.Message);
            }
        }

    }
}
