﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LMS.Models
{
    public partial class Course
    {
        public Course()
        {
            Subjects = new HashSet<Subject>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string TrainerName { get; set; }
        public long? Fees { get; set; }
        public string Duration { get; set; }
        public string Description { get; set; }

        public virtual ICollection<Subject> Subjects { get; set; }
    }
}
