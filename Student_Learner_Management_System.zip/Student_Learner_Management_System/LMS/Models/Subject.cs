﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LMS.Models
{
    public partial class Subject
    {
        public Subject()
        {
            Books = new HashSet<Book>();
        }

        public int SubjectId { get; set; }
        public string SubjectName { get; set; }
        public int CourseId { get; set; }

        public virtual Course Course { get; set; }
        public virtual ICollection<Book> Books { get; set; }
    }
}
