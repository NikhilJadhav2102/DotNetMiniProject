﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LMS.Models
{
    public partial class Role
    {
        public int Id { get; set; }
        public string Role1 { get; set; }
    }
}
