﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Student_Learner_Management_System.Models
{
    public partial class Subject
    {
        public Subject()
        {
            Books = new HashSet<Book>();
        }

        public int SubjectId { get; set; }
        public string SubjectName { get; set; }
        public int CourseId { get; set; }

        public virtual Course Course { get; set; }
        public virtual ICollection<Book> Books { get; set; }
    

    //To read the data
    public static void fetchData()
    {
        var cntx = new Learner_Mgmt_SysContext();


        var res = from val in cntx.Subjects
                  select val;

        foreach (var item in res)
        {
            Console.WriteLine(item.SubjectName);
        }
    }

    public static void addData()
    {
        string subjectName;
        int courseId;

        var cntx = new Learner_Mgmt_SysContext();

        Subject data = new Subject();

        //accepting data from user
        Console.WriteLine("Enter the Subject Name");
        subjectName = Console.ReadLine();

        Console.WriteLine("Enter the Course id");
        courseId = Convert.ToInt32(Console.ReadLine());



        data.SubjectName = subjectName;
        data.CourseId = courseId;

        cntx.Subjects.Add(data);
        cntx.SaveChanges();

            var val = cntx.SaveChanges();

            if (val > 0)
            {
                Console.WriteLine("Subject inserted successfully");
            }
            else
            {
                Console.WriteLine("Something went wrong....");
            }
           
    }

    public static void updateData()
    {
        int id;
        string subjectName;
        int courseId;



        var cntx = new Learner_Mgmt_SysContext();


        Console.WriteLine();
            fetchData();
            Console.WriteLine();

       
        Console.WriteLine("Enter the subject  id");
        id = Convert.ToInt32(Console.ReadLine());

        var subject = cntx.Subjects.FirstOrDefault(x => x.SubjectId == id);


        Console.WriteLine("Enter the subject name");
        subjectName = Console.ReadLine();

        Console.WriteLine("Enter the Course Id");
        courseId = Convert.ToInt32(Console.ReadLine());

        subject.SubjectName = subjectName;
        subject.CourseId = courseId;

        var val = cntx.SaveChanges();

        if (val > 0)
        {
            Console.WriteLine("Successfully updated..!!!");
        }
        else
        {
            Console.WriteLine("Something went wrong....");
        }
    }

    public static void deleteData()
    {
        var cntx = new Learner_Mgmt_SysContext();

        int id;

        Console.WriteLine("Enter the  id which you want to delete..");
        id = Convert.ToInt32(Console.ReadLine());

        var subject = cntx.Subjects.FirstOrDefault(x => x.SubjectId == id);
        cntx.Subjects.Remove(subject);

        var val = cntx.SaveChanges();

        if (val > 0)
        {
            Console.WriteLine("Removed successfully..!!!");
        }
        else
        {
            Console.WriteLine("Something went wrong....");
        }

    }


        public static void deleteSubject() {
            bool flag = false;

            fetchData();
            Console.WriteLine();
            Console.WriteLine("Enter subject to be deleted");
            string name = Console.ReadLine();

            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<Subject> uList = ctx.Subjects.ToList();

            Console.Clear(); //Clearing console

            foreach (var item in uList)
            {
                if (item.SubjectName == name)
                {
                    ctx.Subjects.Remove(item);
                    ctx.SaveChanges();
                    flag = true;
                    Console.WriteLine("Subject deleted Succefully");

                }

            }

            if (flag == false)
            {
                Console.WriteLine("Subject Not Found");
            }
        }
}
}
