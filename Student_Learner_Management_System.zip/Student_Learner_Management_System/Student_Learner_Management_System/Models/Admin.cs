﻿using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable

namespace Student_Learner_Management_System.Models
{
    public partial class Admin
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public long Contact { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public static void ViewAllUsers(string user)
        {
            Console.WriteLine();
            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> uList = ctx.Users.ToList();

            Console.Clear(); //Clearing console

            bool flag = true;

            foreach (var item in uList)
            {
                if (item.Role == "student" && user == "student")
                {
                    Console.WriteLine("Id:" + item.Id + "\tName: " + item.Name + " \tContact:" + item.Contact + "\n" + "\tEmail:" + item.Email + "\tDob:" + item.Dob + "\tCourse Name:" + "\n" + item.CourseName + "\tLocation: " + item.Location + "\tRole: " + item.Role + "\tSubject: " + item.Subject);

                    Console.WriteLine();
                    flag = false;
                }

                if (item.Role == "trainer" && user == "trainer")
                {
                    Console.WriteLine("Id:" + item.Id + "\tName: " + item.Name + " \tContact:" + item.Contact + "\n" + "\tEmail:" + item.Email + "\tDob:" + item.Dob + "\tCourse Name:" + "\n" + item.CourseName + "\tLocation: " + item.Location + "\tRole: " + item.Role + "\tSubject: " + item.Subject);
                    Console.WriteLine();
                    flag = false;
                }


            }
            if (flag)
            {
                Console.WriteLine("No record found \n");
            }
        }
        public static void UpdateStudentTrainerProfile()
        {
            Console.WriteLine("Enter email id of user to be updated");
            string email = Console.ReadLine();

            Console.WriteLine("Enter course");
            ViewAllCourses();
            string updatedCourse = Console.ReadLine();

            Console.WriteLine("Enter Location");
            string updatedLocation = Console.ReadLine();

            Console.WriteLine("Enter subject");
            string updatedSubject = Console.ReadLine();


            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> uList = ctx.Users.ToList();

            Console.Clear(); //Clearing console

            bool flag = true;

            foreach (var item in uList)
            {
                if (item.Email == email)
                {

                    item.Location = updatedLocation;
                    item.Subject = updatedSubject;
                    item.CourseName = updatedCourse;

                    ctx.Users.Update(item);
                    ctx.SaveChanges();

                    Console.Clear(); //Clearing console

                    Console.WriteLine("Successfully Updated ");

                    // displaying updated records
                    Console.WriteLine("Id:" + item.Id + "\t|\tName: " + item.Name + " \t|\tContact:" + item.Contact + "\n" + "\t|\tEmail:" + item.Email + "\t|\tDob:" + item.Dob + "\t|\tCourse Name:" + item.CourseName + "\n" + "\t|\tLocation: " + item.Location + "\t|\tRole: " + item.Role + "\t|\tSubject: " + item.Subject);

                    flag = false;
                }
            }

            if (flag)
            {
                Console.WriteLine("No record found \n");
            }
        }

        public static void DeleteStudent()
        {
            bool flag = false;
            Console.WriteLine("Enter Student email to be deleted");
            string email = Console.ReadLine();

            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> uList = ctx.Users.ToList();

            Console.Clear(); //Clearing console

            foreach (var item in uList)
            {
                if (item.Email == email && item.Role == "student")
                {
                    ctx.Users.Remove(item);
                    ctx.SaveChanges();
                    flag = true;
                    Console.WriteLine("Student deleted Succefully");

                }

            }

            if (flag == false)
            {
                Console.WriteLine("Student Not Found");
            }


        }

        public static void ViewAllTrainers()
        {
            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> tList = ctx.Users.ToList();

            bool flag = true;


            foreach (var item in tList)
            {
                if (item.Role == "trainer")
                {
                    Console.WriteLine("Id:" + item.Id + "\tName: " + item.Name + " \tContact:" + item.Contact + "\n" + "\tEmail:" + item.Email + "\tDob:" + item.Dob + "\tCourse Name:" + item.CourseName + "\n" + "\tLocation: " + item.Location + "\tRole: " + item.Role + "\tSubject: " + item.Subject);

                    flag = false;
                }


            }

            if (flag)
            {
                Console.WriteLine("No record found \n");
            }
        }



        public static void DeleteTrainer()
        {
            bool flag = false;
            Console.WriteLine("\n Enter Trainer email to be deleted");
            string email = Console.ReadLine();

            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> uList = ctx.Users.ToList();

            Console.Clear(); //Clearing console

            foreach (var item in uList)
            {
                if (item.Email == email && item.Role == "trainer")
                {
                    ctx.Users.Remove(item);
                    ctx.SaveChanges();
                    flag = true;
                    Console.WriteLine("Trainer deleted Succefully");

                }

            }
            if (flag == false)
            {
                Console.WriteLine("Trainer Not Found");
            }

        }

        public static void ViewAllCourses()
        {
            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<Course> cList = ctx.Courses.ToList();

            bool flag = true;

            Console.WriteLine("CourseId\t | \t CourseName\t | \t TrainerName \t | \t Fees \t | \t Duration \t | \t Description \n");
            Console.WriteLine("----------------------------------------------------------");
            foreach (var item in cList)
            {
              
                Console.Write(item.Id + "\t"+item.Name + "\t" + item.TrainerName + "\t" + item.Fees + "\t" + item.Duration + "\t" + item.Description + "\n");
                Console.WriteLine();
                flag = false;

            }
            Console.WriteLine("----------------------------------------------------------");

            if (flag)
            {
                Console.WriteLine("No record found \n");
            }
        }

        public static void ViewAllRoles()
        {
            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<Role> cList = ctx.Roles.ToList();

            bool flag = true;

            foreach (var item in cList)
            {
                if (item.Role1 != "admin") { 
                Console.Write(" - " + item.Role1);
                Console.WriteLine();
                flag = false;
                }
            }

            if (flag)
            {
                Console.WriteLine("No record found \n");
            }
        }


        public static void UpdateCourse()
        {

            ViewAllCourses();

            int courseFees, id;
            string courseName, duration, description, trainerName;

            var cntx = new Learner_Mgmt_SysContext();


            Console.WriteLine();

            Console.WriteLine("Enter the Course id");

            id = Convert.ToInt32(Console.ReadLine());

            var course = cntx.Courses.FirstOrDefault(x => x.Id == id);


            Console.WriteLine("Enter the description");
            description = (Console.ReadLine());

            Console.WriteLine("Enter the Course fees");
            courseFees = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Course Trainer name");
            trainerName = Console.ReadLine();

            Console.WriteLine("Enter the Course name");
            courseName = Console.ReadLine();

            Console.WriteLine("Enter the Course duration");
            duration = Console.ReadLine();

            course.Fees = courseFees;
            course.Description = description;
            course.Duration = duration;
            course.Name = courseName;
            course.TrainerName = trainerName;

            var val = cntx.SaveChanges();

            if (val > 0)
            {
                Console.WriteLine("Successfully updated..!!!");
            }
            else
            {
                Console.WriteLine("Something went wrong....");
            }
        }

        public static void DeleteCourse()
        {
            ViewAllCourses();

            var cntx = new Learner_Mgmt_SysContext();

            int id;

            Console.WriteLine("Enter the  id which you want to delete..");

            id = Convert.ToInt32(Console.ReadLine());

            var course = cntx.Courses.FirstOrDefault(x => x.Id == id);
            cntx.Courses.Remove(course);

            var val = cntx.SaveChanges();

            if (val > 0)
            {
                Console.WriteLine("Removed successfully..!!!");
            }
            else
            {
                Console.WriteLine("Something went wrong....");
            }

        }

        public static void AddCourse()
        {
        
            int courseFees;
            string courseName, duration, description, trainerName;
           
            var cntx = new Learner_Mgmt_SysContext();

            Course data = new Course();

            //accepting data from user
            Console.WriteLine("Enter the Course Name to be inserted");
            courseName = Console.ReadLine();

          
            Console.WriteLine("Enter the Course fees");
            courseFees = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Course duration");
            duration = Console.ReadLine();

            Console.WriteLine("Enter the Course Description");
           description = Console.ReadLine();

            Console.WriteLine("Enter the Course Trainer Name");
            trainerName = Console.ReadLine();
            


            data.Name = courseName;
            data.TrainerName = trainerName;
            data.Fees = courseFees;
            data.Duration = duration;
            data.Description = description;
            data.TrainerName = trainerName;

            cntx.Courses.Add(data);
            cntx.SaveChanges();

            Console.WriteLine();
            Console.WriteLine("Course " + data.Name+ " inserted successfully");
            Console.WriteLine();

        }
        public static void ViewAllSubject()
        {
            {
                Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
                List<Subject> sList = ctx.Subjects.ToList();
                bool flag = true;

                foreach (var item in sList)
                {
                 
                    Console.WriteLine(" - " + item.SubjectName);

                    flag = false;

                }
                Console.WriteLine();

                if (flag)
                {
                    Console.WriteLine("No record found \n");
                }
            }

        }

        public static void ViewProfile(string email)
        {
            bool flag = true;
            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<Admin> uList = ctx.Admins.ToList();

            Console.Clear(); //Clearing console

            Console.WriteLine("\n Your profile details:\n");

            foreach (var item in uList)
            {
                if (item.Email == email)
                {

                        Console.WriteLine("Id:" + item.Id + "\t|\tName: " + item.Name + " \t|\tContact:" + item.Contact + "\t|\tEmail:" + item.Email + "\t|\tPassword:" + item.Password);
                    flag = false;
                }
            }

            if (flag)
            {
                Console.WriteLine("No record found \n");
            }
        }
    }
}