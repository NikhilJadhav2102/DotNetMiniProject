﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;


#nullable disable

namespace Student_Learner_Management_System.Models
{
    public partial class Book
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public int SubjectId { get; set; }

        public virtual Subject Subject { get; set; }

        //To read the data
        public static void fetchData()
        {
            var cntx = new Learner_Mgmt_SysContext();


            var res = from val in cntx.Books
                      select val;

            Console.WriteLine("BookId  \t | \t  BookName  \t | \t  SubjectId");
            Console.WriteLine("-----------------------------------");

            foreach (var item in res)
            {

                Console.WriteLine(item.BookId + "\t" + item.BookName + "\t" + item.SubjectId + "\t");       
            }
        }

        public static void addData()
        {
            string BookName;
            int SubjectId;
           

            var cntx = new Learner_Mgmt_SysContext();
            Book data = new Book();

            //accepting data from user
            Console.WriteLine("Enter the Book Name");
            BookName = Console.ReadLine();

            Console.WriteLine("Enter the subjectId");
            SubjectId = Convert.ToInt32(Console.ReadLine());

            data.BookName = BookName;
            data.SubjectId = SubjectId;
        
            cntx.Books.Add(data);
            cntx.SaveChanges();

        }

        public static void updateData()
        {
            int BookId;
            string BookName;
            int SubjectId;
         

            var cntx = new Learner_Mgmt_SysContext();


            Console.WriteLine();
 
            Console.WriteLine("Enter the Book id");
   
            fetchData();

            Console.WriteLine("\n Enter Book ID \n");
            BookId = Convert.ToInt32(Console.ReadLine());

            var book = cntx.Books.FirstOrDefault(x => x.BookId == BookId);


            Console.WriteLine("Enter the Book name");
            BookName = Console.ReadLine();

            Console.WriteLine("Enter the subject id");
            SubjectId = Convert.ToInt32(Console.ReadLine());

           
            book.BookName = BookName;
            book.SubjectId = SubjectId;
         

            var val = cntx.SaveChanges();

            if (val > 0)
            {
                Console.WriteLine("Successfully updated..!!!");
            }
            else
            {
                Console.WriteLine("Something went wrong....");
            }
        }

        public static void deleteData()
        {
            var cntx = new Learner_Mgmt_SysContext();

            int id;

            Console.WriteLine("\nAvailable Books: \n");
            fetchData();
      
            Console.WriteLine("Enter book ID");
            id = Convert.ToInt32(Console.ReadLine());

            var book = cntx.Books.FirstOrDefault(x => x.BookId == id);
            cntx.Books.Remove(book);

            var val = cntx.SaveChanges();

            if (val > 0)
            {
                Console.WriteLine("Removed successfully..!!!");
            }
            else
            {
                Console.WriteLine("Something went wrong....");
            }

        }

    }
}
