﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Student_Learner_Management_System.Models
{
    public partial class Role
    {
        public int Id { get; set; }
        public string Role1 { get; set; }
    }
}
