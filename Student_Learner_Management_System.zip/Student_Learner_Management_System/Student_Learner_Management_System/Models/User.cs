﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

#nullable disable

namespace Student_Learner_Management_System.Models
{
    public partial class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public long Contact { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public DateTime? Dob { get; set; }
        public string Location { get; set; }
        public string Role { get; set; }
        public string Subject { get; set; }
        public string CourseName { get; set; }


        static long contact;
        static string name;



        // LOGIN AND SIGNUP - START


        public static void SignupUser()
        {

            string password = "";
            DateTime dob;

            ValidateName();

            void ValidateName()
            {

                Console.WriteLine("Name:");

                name = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(name) || name.All(char.IsDigit))
                {
                    Console.WriteLine("Please enter valid name");
                    ValidateName();
                }

            }

            Console.WriteLine();

            ValidateContact();

            Console.WriteLine();

            void ValidateContact()
            {
                Console.WriteLine("Contact:");

                string phone = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(phone) && phone.Length == 10)
                {
                    contact = Convert.ToInt64(phone);
 
                }

                else
                {
                    Console.WriteLine("Please enter valid contact");
                    ValidateContact();

                }
            }
            Console.WriteLine();


            ValidateDob();

            void ValidateDob()
            {
                Console.WriteLine("Dob:");
                string date = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(date))
                {

                    dob = Convert.ToDateTime(date);
                }
                else
                {
                    Console.WriteLine("Please enter valid Date of Birth in format YYYY-MM-DD");
                    ValidateDob();
                }
            }



            Console.WriteLine();

            Console.WriteLine("Location:");
            string location = Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("Enter Subject");

            Admin.ViewAllSubject();


            string subject = Console.ReadLine();

            Console.WriteLine();

            Console.WriteLine("Enter Course Name: ");

            Admin.ViewAllCourses();

            Console.WriteLine("Enter Course Name: ");

            string course = Console.ReadLine();
            Console.WriteLine();

            string email;
            InputEmail();

            Console.WriteLine();

            void InputEmail()
            {
                Console.WriteLine("Email id:");

                email = Console.ReadLine();

                string pattern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";

                //if email is invalid
                if (!Regex.IsMatch(email, pattern))
                {
                    Console.WriteLine(email + " not a valid Email address. Please enter correct email \n ");
                    InputEmail();
                }

            }

            // Masking password 

            Console.WriteLine();

            string pass = "";
            PasswordMasking();

            void PasswordMasking()
            {

                Console.Write("Enter your password: ");
                ConsoleKeyInfo key;

                do
                {
                    key = Console.ReadKey(true);

                    // Backspace Should Not Work
                    if (key.Key != ConsoleKey.Backspace)
                    {
                        pass += key.KeyChar;
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write("\b");
                    }
                }
                // Stops Receving Keys Once Enter is Pressed
                while (key.Key != ConsoleKey.Enter);

                Console.WriteLine();

                if (string.IsNullOrWhiteSpace(pass) || pass.Length < 8)
                {
                    Console.WriteLine("\nPlease enter password with length > 8");

                 
                    PasswordMasking();
                }

                Console.WriteLine();

                Console.WriteLine("\n\nRole:");

                Admin.ViewAllRoles();

                string UserRole = Console.ReadLine();


                User u = new User() { Name = name, Contact = contact, Dob = dob, Location = location, Subject = subject, CourseName = course, Email = email, Password = pass, Role = UserRole };


                Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
                ctx.Users.Add(u);
                ctx.SaveChanges();

                Console.Clear(); //Clearing console

                Console.WriteLine("Successfully Registered " + u.Role + "\n");

                Console.WriteLine("--------------------------------------------\n");
                if (u.Role == "trainer")
                {
                    Console.WriteLine();
                    Menu.MenuListforTrainer(email);
                }

                if (u.Role == "student")
                {
                    Console.WriteLine();
                    Menu.MenuListforStudent(email);
                }
            }

        }
        public static void LoginUser()

        {
            bool flag = false;
            Console.WriteLine("Please enter email id");
            string email = Console.ReadLine();

            Console.WriteLine();

            Console.WriteLine("Please enter password");
            string password = Console.ReadLine();

            if (email == null || password == null)
            {
                Console.WriteLine("Please enter all fields");
            }

            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> ulist = ctx.Users.ToList();
            foreach (var item in ulist)
            {
                if (item.Email == email && item.Password == password)
                {
                    Console.Clear(); //Clearing console

                    Console.WriteLine("Successfully Logged in " + item.Role);
                    Console.WriteLine("---------------------------------------------");
                    flag = true;
                    if (item.Role == "student")
                    {
                        Menu.MenuListforStudent(email);
                    }

                    if (item.Role == "trainer")
                    {
                        Menu.MenuListforTrainer(email);
                    }
                }

            }
            if (flag == false)
            {
                
                Console.WriteLine("Invalid EmailID or Password. Please try again");
                LoginUser();
            }


        }

        public static void LoginAdmin()
        {
            bool flag = false;
            Console.WriteLine("Please enter email id");
            string email = Console.ReadLine();

            Console.WriteLine();

            Console.WriteLine("Please enter password");
            

            string password = Console.ReadLine();

            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<Admin> aList = ctx.Admins.ToList();

            foreach (var item in aList)
            {
                if (item.Email == email && item.Password == password)
                {
                    Console.Clear();
                    Console.WriteLine("Admin Successfully Logged in ");
                    Console.WriteLine("---------------------------------------------");
                    flag = true;
                    Menu.MenuListforAdmin(email);

                }

            }
            if (flag == false)
            {
                Console.Clear();
                Console.WriteLine("Invalid EmailID or Password. Please try again");
                LoginAdmin();
            }


        }

        //

        public static void ViewProfile(string email)
        {
            bool flag = true;
            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> uList = ctx.Users.ToList();

            Console.Clear(); //Clearing console

            Console.WriteLine("\n Your profile details:\n");

            foreach (var item in uList)
            {
                if (item.Email == email)
                {


                    Console.WriteLine("Id:" + item.Id + "\t|\tName: " + item.Name + " \t|\tContact:" + item.Contact + "\t|\tEmail:" + item.Email + "\t|\tDob:" + item.Dob + "\t|\tCourse Name:" + item.CourseName + "\t|\tLocation: " + item.Location + "\t|\tRole: " + item.Role + "\t|\tSubject: " + item.Subject);
                    flag = false;
                }
            }

            if (flag)
            {
                Console.WriteLine("No record found \n");
            }
        }

        public static void UpdateProfile(string email)
        {

            Admin.ViewAllCourses();


            Console.WriteLine("\nEnter course");
            string updatedCourse = Console.ReadLine();

            Console.WriteLine("\nEnter Location");
            string updatedLocation = Console.ReadLine();

            Admin.ViewAllSubject();

            Console.WriteLine("\nEnter subject");
            string updatedSubject = Console.ReadLine();


            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> uList = ctx.Users.ToList();

            Console.Clear(); //Clearing console

            bool flag = true;

            foreach (var item in uList)
            {
                if (item.Email == email)
                {
               
                    item.Location = updatedLocation;
                    item.Subject = updatedSubject;
                    item.CourseName = updatedCourse;

                    ctx.Users.Update(item);
                    ctx.SaveChanges();

                    Console.Clear(); //Clearing console

                    Console.WriteLine("\nSuccessfully Updated Record");
                    Console.WriteLine("---------------------------------------------\n");

                    // displaying updated records
                    Console.WriteLine("Id:" + item.Id + "\t|\tName: " + item.Name + " \t|\tContact:" + item.Contact + "\t|\tEmail:" + item.Email + "\t|\tDob:" + item.Dob + "\t|\tCourse Name:" + item.CourseName + "\t|\tLocation: " + item.Location + "\t|\tRole: " + item.Role + "\t|\tSubject: " + item.Subject +"\n");

                    flag = false;
                }
            }

            if (flag)
            {
                Console.WriteLine("\nNo record found\n");
            }
        }


        public static void DeleteProfile(string email)
        {

            bool flag = true;
            Learner_Mgmt_SysContext ctx = new Learner_Mgmt_SysContext();
            List<User> uList = ctx.Users.ToList();

            Console.Clear(); //Clearing console

            foreach (var item in uList)
            {
                if (item.Email == email && item.Role == "trainer")
                {
                    ctx.Users.Remove(item);
                    ctx.SaveChanges();
                    Console.WriteLine("Trainer deleted Succefully");
                    flag = false;

                }

                if (item.Email == email && item.Role == "student")
                {
                    ctx.Users.Remove(item);
                    ctx.SaveChanges();
                    Console.WriteLine("Student deleted Succefully");
                    flag = false;
                }

              
            }
     

            if (flag)
            { Console.WriteLine("User Not Found"); }

            Menu.MenuList();

        }       
    
        // TRAINER - END
    }
}