﻿using System;


namespace Student_Learner_Management_System
{

    class Program
    {

        static void Main(string[] args)
        {
            try
            {
               
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.White;
            
                Menu.MenuList();
             
            }

            catch (Exception e)
            {
                Console.WriteLine("Exception occurred. Details: " + e.Message);
            }
        }

    }
}
