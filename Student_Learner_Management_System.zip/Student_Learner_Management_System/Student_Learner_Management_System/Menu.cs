﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_Learner_Management_System.Models;

namespace Student_Learner_Management_System
{
    class Menu
    {

        static int choice;

        // COMMON MENU LIST - LOGIN AND SIGNUP
        public static void MenuList()
        {
           
            Console.WriteLine("***** WELCOME TO LEARNER MANAGEMENT SYSTEM ***** \n  ------------------------------ \n\n Please Login / Signup to continue: \n\n --------------- \n \n Options: \n Student: \n 1. Signup  \n 2. Login \n \n Trainer \n 3. Signup \n 4. Login  \n \n 5.Admin Login \n 6. Close \n ---------------- \n ---------------");

            MenuOption();

            void MenuOption() {

                Console.WriteLine("Enter option: ");
                string option = Console.ReadLine();
                int choice = -1;

                if (!string.IsNullOrWhiteSpace(option) && option.All(char.IsDigit))
                {
                    choice = Convert.ToInt32(option);

                    if (choice == 1 || choice == 3)
                    {
                        User.SignupUser();
                    }

                    else if (choice == 2 || choice == 4)
                    {
                        User.LoginUser();
                    }

                    else if (choice == 5)
                    {
                        User.LoginAdmin();
                    }

                    else if (choice == 6)
                    {
                        Environment.Exit(0);
                    }

                    else
                    {
                        Console.WriteLine("Invalid option selected \n");
                        MenuOption();
                    }
                }

                else
                {
                    Console.WriteLine("Invalid option selected \n");
                    MenuOption();
                }


                Console.WriteLine("Please enter details: \n --------------- \n");
            }

        }

        public static void MenuListforStudent(string email)
        {
            int MenulistforStudent()
            {

                Console.WriteLine("\n\n---------------\nEnter operation to be performed: \n --------------- \n \n 1. View Profile \n 2. Update Profile \n 3. View All Courses \n 4. View all subjects \n 5. Delete Profile   \n 6. View all Books \n 7. Logout \n 0. Exit \n --------------- \n");

                choice = Convert.ToInt32(Console.ReadLine());
                return choice;
            }


            while ((choice = MenulistforStudent()) != 0)
            {
                switch (choice)
                {
                    case 1:
                        User.ViewProfile(email);

                        break;

                    case 2:
                        User.UpdateProfile(email);

                        break;

                    case 3:  Admin.ViewAllCourses();

                        break;

                    case 4:
                        Admin.ViewAllSubject();
                        break;
                    
                    case 5:
                        User.DeleteProfile(email);

                        break;

                    case 6: //view all books
                        Book.fetchData();
                        break;


                    case 7:
                        Console.Clear();
                        MenuList();
                        break;

                    default:
                        Console.WriteLine("Please enter valid option");
                        break;

                }
            }
        }

        public static void MenuListforAdmin(string email)
        {

            int MenulistforAdmin()
            {
              

                Console.WriteLine("\n \n Enter operation to be performed: \n --------------- \n \n 1. View all students \n 2. Update student \n 3. Delete Student \n 4. View all trainers \n 5. Update trainer \n 6. Delete trainer  \n 7. View all courses \n 8. Update course \n 9. Delete course \n 10. Add course \n 11. View all subjects \n 12. Add subject \n 13. Delete subject \n 14. Update subject \n 15. View All Books  \n 16. Add Book \n 17. Update Book \n 18. Delete Book  \n 19. Logout \n 20. View own profile \n 0. Exit \n --------------- \n ");

                int choice = Convert.ToInt32(Console.ReadLine());
                return choice;
            }

            while ((choice = MenulistforAdmin()) != 0)
            {
                switch (choice)
                {
                    case 1:
                        Admin.ViewAllUsers("student");
                        break;

                    case 2:
                        Admin.UpdateStudentTrainerProfile();

                        break;

                    case 3:
                        Admin.DeleteStudent();

                        break;

                    case 4:
                        Admin.ViewAllUsers("trainer");

                        break;
                    case 5:
                        Admin.UpdateStudentTrainerProfile();

                        break;
                    case 6:
                        Admin.DeleteTrainer();
                        break;

                    case 7:
                        Admin.ViewAllCourses();
                        break;

                    case 8:
                        Admin.UpdateCourse();

                        break;
                    case 9:
                        Admin.DeleteCourse();

                        break;
                    case 10:
                        Admin.AddCourse();
                        break;

           
                    case 11:
                        Subject.fetchData();
                        break;

                    case 12:
                        Subject.addData();
                        break;

                    case 13:
                        Subject.deleteSubject();
                        break;

                    case 14:
                        Subject.updateData();
                        break;


                    case 15: //show books
                        Book.fetchData();
                        break;

                    case 16: //add book
                        Book.addData();
                        break;

                    case 17: //update book
                        Book.updateData();
                        break;

                    case 18: //delete book
                        Book.deleteData();
                        break;


                    case 19:
                        Console.Clear();
                        MenuList();
                        break;

                    case 20:
                        Admin.ViewProfile(email);
                        break;


                    default:
                        Console.WriteLine("Please enter valid option");
                        break;

                }
            }
        }

        public static void MenuListforTrainer(string email)
        {

            int MenulistforTrainer()
            {

                Console.WriteLine("\n \n Enter operation to be performed: \n --------------- \n \n 1. View Profile \n 2. Update Profile \n 3. Delete Profile \n 4. View Courses \n 5. Add Course \n 6. Update Course \n 7. View all subjects \n8. View All Books  \n9. Add Book \n10. Update Book \n11. Delete Book \n 12. logout  \n0. Exit \n --------------- \n");

                choice = Convert.ToInt32(Console.ReadLine());
                return choice;
            }

            while ((choice = MenulistforTrainer()) != 0)
            {
                switch (choice)
                {
                    case 1:
                        User.ViewProfile(email);

                        break;

                    case 2:
                        User.UpdateProfile(email);

                        break;

                    case 3:
                        User.DeleteProfile(email);

                        break;

                    case 4:  Admin.ViewAllCourses();

                        break;
                    case 5:  Admin.AddCourse();

                        break;
                    case 6:  Admin.UpdateCourse();

                        break;

                    //  Console.WriteLine("Enter operation to be performed: \n --------------- \n \n 1. View Profile \n 2. Update Profile \n 3. Delete Profile \n 4. View Courses \n 5. Add Course \n 6. Update Course \n 7. View all subjects \n8. View Book  \n9. Add Book \n10. Update Book \n11. Delete Book \n 12. logout  \n0. Exit \n --------------- \n");

                    case 7:
                        Admin.ViewAllSubject();
                        break;

                    case 8:
                        Book.fetchData();
                        break;

                    case 9:
                        Book.addData();
                        break;

                    case 10:
                        Book.updateData();
                        break;

                    case 11:
                        Book.deleteData();
                        break;

                   
                    case 12:
                        Console.Clear();
                        MenuList();
                        break;


                    default:
                        Console.WriteLine("Please enter valid option");
                        break;

                }
            }
        }
    }
}
